package com.outbacksmp.richman.schedulers;

import com.outbacksmp.richman.RichManPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class CountdownScheduler {

    private final RichManPlugin plugin;
    private final ZoneId zoneId;

    public CountdownScheduler(RichManPlugin plugin) {
        this.plugin = plugin;
        this.zoneId = ZoneId.systemDefault();
    }

    public void scheduleCountdowns(LocalDateTime eventTime) {
        if (!plugin.getConfig().getBoolean("countdown.enabled", true)) {
            return;
        }

        LocalDateTime now = LocalDateTime.now(zoneId);
        if(!eventTime.isAfter(now)) {
            return;
        }

        int startHoursBefore = plugin.getConfig().getInt("countdown.hourly.start-hours-before", 6);
        String hourlyMsg = color(plugin.getConfig().getString("countdown.hourly.message", "&7A new &6&lRich Man &r&7will be drawn today! Get your &amoney &7up."));

        for (int h = startHoursBefore; h > 1; h--) {
            LocalDateTime when = eventTime.minusHours(h);

            scheduleIfFuture(when, () -> broadcast(hourlyMsg));
        }

        scheduleIfFuture(eventTime.minusHours(1), () -> broadcast(color(plugin.getConfig().getString("countdown.hour-before.message", "&6&lRich Man &r&eevent in &61 hour&f! &aSell &fyour stuff now!"))));
        scheduleIfFuture(eventTime.minusMinutes(5), () -> broadcast(color(plugin.getConfig().getString("countdown.minute-5.message", "&6&lRich Man &r&eevent in &65 minutes&f!"))));
        scheduleIfFuture(eventTime.minusMinutes(1), () -> broadcast(color(plugin.getConfig().getString("countdown.minute-1.message", "&6&lRich Man &r&eevent in &61 minute&f!"))));
        scheduleIfFuture(eventTime.minusSeconds(30), () -> broadcast(color(plugin.getConfig().getString("countdown.second-30.message", "&6&lRich Man &r&eevent in &630 seconds&f! Make sure you remember to &asell&f!"))));

        String finalTemplate = plugin.getConfig().getString("countdown.final-10.message", "&6&lRich Man &r&ein &6&l%seconds%s&r&f...!");

        for (int sec = 10; sec >= 1; sec--) {
            final int s = sec;
            LocalDateTime when = eventTime.minusSeconds(s);
            scheduleIfFuture(when, () -> {
                String msg = finalTemplate.replace("%seconds%", String.valueOf(s));
                broadcast(color(msg));
            });
        }
    }

    private void scheduleIfFuture(LocalDateTime runAt, Runnable task) {
        LocalDateTime now = LocalDateTime.now(zoneId);
        if (!runAt.isAfter(now)) {
            return;
        }

        long seconds = Duration.between(now, runAt).getSeconds();
        long ticks = seconds * 20L;
        if (ticks <= 0) {
            return;
        }

        Bukkit.getScheduler().runTaskLater(plugin, task, ticks);
    }

    private void broadcast(String message) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(message);
        }
        plugin.getServer().getLogger().info("[RICHMAN BROADCAST] " + message);
    }

    public String color(String in) {
        return ChatColor.translateAlternateColorCodes('&', in);
    }

}
