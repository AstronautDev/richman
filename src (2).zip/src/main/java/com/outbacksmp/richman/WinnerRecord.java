package com.outbacksmp.richman;

import java.util.UUID;

public record WinnerRecord(UUID uuid, String name, double amount) {}